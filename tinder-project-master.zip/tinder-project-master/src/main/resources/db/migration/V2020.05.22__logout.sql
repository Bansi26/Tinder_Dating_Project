INSERT INTO activity (user_id, logout_time) VALUES (4, '2020-06-06 07:00:00.000000');
INSERT INTO activity (user_id, logout_time) VALUES (2, '2020-06-06 07:08:20.000000');
INSERT INTO activity (user_id, logout_time) VALUES (6, '2020-06-04 07:09:09.000000');
INSERT INTO activity (user_id, logout_time) VALUES (3, '2020-06-03 00:49:54.000000');
INSERT INTO activity (user_id, logout_time) VALUES (1, '2020-06-05 07:00:52.000000');
INSERT INTO activity (user_id, logout_time) VALUES (5, '2020-06-06 00:43:11.000000');